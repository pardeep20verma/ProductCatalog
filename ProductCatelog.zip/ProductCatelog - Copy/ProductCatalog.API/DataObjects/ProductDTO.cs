﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductCatalog.API.DataObjects
{
    public class ProductDTO
    {
        public int id { get; set; }
        public string name { get; set; }

        public string description { get; set; }

        public string imageURL { get; set; }

        public double price { get; set; }

        public double discount { get; set; }
    }
}
