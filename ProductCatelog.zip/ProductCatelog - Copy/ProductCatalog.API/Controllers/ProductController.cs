﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ProductCatalog.API.DataObjects;
using Microsoft.AspNetCore.Cors;

namespace ProductCatalog.API.Controllers
{
    [EnableCors("MyPolicy")]
    [Route("api/[controller]")]
    public class ProductController : Controller
    {
        private static List<ProductDTO> ProductCat = new List<ProductDTO>()
        {
            new ProductDTO(){ id=1,name="Red", description="Its Red color",price=10.00, discount=1,imageURL="" },
            new ProductDTO(){ id=2,name="Blue", description="Its Blue color",price=12.00, discount=2,imageURL="" },
            new ProductDTO(){ id=3,name="Green", description="Its Green color",price=10.00, discount=1,imageURL="" },
            new ProductDTO(){ id=4,name="Yellow", description="Its yellow color",price=10.00, discount=2,imageURL="" },
            new ProductDTO(){ id=5,name="Black", description="Its Black color",price=14.00, discount=0.4,imageURL="" },
            new ProductDTO(){ id=6,name="White", description="Its White color",price=15.00, discount=3,imageURL="" },
            new ProductDTO(){ id=7,name="Black & White", description="Its Black & While color",price=13.00, discount=2,imageURL="" },
            new ProductDTO(){ id=8,name="Orange", description="Its Orange color",price=19.00, discount=1,imageURL="" }
        };


        // GET api/values
        [HttpGet]
        public IEnumerable<ProductDTO> Get()
        {
            return ProductCat;
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public ProductDTO Get(int id)
        {
            return ProductCat.Find(f=>f.id==id);
        }

        // POST api/values
        [HttpPost]
        public void Post([FromBody]ProductDTO item)
        {
            ProductCat.Add(item);
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            var data = ProductCat.Find(f => f.id == id);
            ProductCat.Remove(data);
        }
    }
}
